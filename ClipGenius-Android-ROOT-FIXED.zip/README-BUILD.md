# ClipGenius Android APK build

This archive is arranged so its contents are the repository root (there is no extra enclosing project folder).

## GitHub upload
1. Extract this ZIP on your device/computer.
2. Upload the **contents** into the root of the GitHub repository `Maans` (not the ZIP file itself, and not inside another `Maanmy-app-main` folder).
3. Keep the `.github/workflows/android-apk.yml` path intact.
4. Commit to the `main` branch.
5. Open **Actions → Build Android APK**. When the run succeeds, open it and download the `ClipGenius-debug-apk` artifact.

Firebase config is at `app/google-services.json`; its Android package name must match `applicationId` in `app/build.gradle.kts`.

The workflow builds a **debug APK**. A signed release APK requires a valid upload keystore and the matching GitHub Actions secrets.

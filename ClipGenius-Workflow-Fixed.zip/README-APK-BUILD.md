# ClipGenius Android APK build

This archive contains the Android project files at the archive root.

## GitHub upload
Extract this ZIP, open the extracted project folder, and upload its **contents** (not the outer folder and not the ZIP itself) to the root of your GitHub repository. Keep hidden folders such as `.github` and `.gitignore`.

The workflow is `.github/workflows/android-apk.yml`. It builds the checked-out repository directly; it does not try to unzip `Maanmy-app-with-apk-workflow.zip`.

After committing to `main`, open **Actions → Build Android APK**. When successful, open the run and download the `ClipGenius-debug-apk` artifact.

Firebase configuration is stored at `app/google-services.json`. If this Firebase file belongs to a different Firebase app, replace it with the Android `google-services.json` whose package name matches `com.aistudio.clipgenius.qrvxkt`.
